
class assignment2.c
{
    public:
        assignment2.c();
        virtual ~assignment2.c();

    protected:

    private:
};
