#ifndef ASSAIGNMENT2_H
#define ASSAIGNMENT2_H


class Assaignment2
{
    public:
        Assaignment2();
        virtual ~Assaignment2();

    protected:

    private:
};

#endif // ASSAIGNMENT2_H
