Instructions



1) There are two keys to move the Ball "Left cursor movement key" for left
   and "Right cursor movement key" for right.

2) There is a limitation of "Ball" from right to left to rectangle lines.

3) Caustion: If your "Ball" touch top or bottom of the rectangle lines
   your Bonus Ball will be decreased.

4) There is a "Stack" for keeping Bonus "Balls" with green color at the
   right side.and there is also a "Queue" for putting Score "Balls" with
   yellow color, one Ball can be obtained with 10 score.

5) After getting 10,20,30,so on, score the speed of Game will be increased
   respectively.


							Thanks
			press any key to back...
