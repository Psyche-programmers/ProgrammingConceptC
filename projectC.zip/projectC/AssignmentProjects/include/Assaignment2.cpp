#include "Assaignment2.h"

Assaignment2::Assaignment2()
{
    //ctor
}

Assaignment2::~Assaignment2()
{
    //dtor
}
