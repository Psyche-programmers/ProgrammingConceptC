#include "assignment2.c.h"

assignment2.c::assignment2.c()
{
    //ctor
}

assignment2.c::~assignment2.c()
{
    //dtor
}
